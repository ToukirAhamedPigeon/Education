﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BFS_Implementing
{
    class Nodes
    {
        public string position {get;set;}
    }
}
